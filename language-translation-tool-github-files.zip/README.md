# Language Translation Tool

A simple Python-based language translation tool built with Gradio and the MyMemory Translation API.

## Features

- Enter text to translate
- Select source language
- Select target language
- Auto-detect source language
- Display translated text in a simple web interface
- Supports several common languages

## Technologies

- Python
- Gradio
- Requests
- MyMemory Translation API

## Run locally

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Start the application:

```bash
python app.py
```

3. Open the local Gradio URL shown in the terminal.

## Google Colab

The project can also be run in Google Colab by installing the requirements and running `app.py` or using the code in the notebook.

## Project Task

This project fulfills the main requirements of a Language Translation Tool:
1. User interface for entering text and selecting languages.
2. Translation API integration.
3. Sending text to the API.
4. Displaying the translated response.
